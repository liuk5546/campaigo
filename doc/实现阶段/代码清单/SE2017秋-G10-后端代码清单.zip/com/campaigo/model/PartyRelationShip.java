package com.campaigo.model;

public class PartyRelationShip {
	private String partyRelationShipId;
	private int partyRelationShipIdCamId;
	private int role;
	
	
	public String getPartyRelationShipId() {
		return partyRelationShipId;
	}
	public void setPartyRelationShipId(String partyRelationShipId) {
		this.partyRelationShipId = partyRelationShipId;
	}
	public int getPartyRelationShipIdCamId() {
		return partyRelationShipIdCamId;
	}
	public void setPartyRelationShipIdCamId(int partyRelationShipIdCamId) {
		this.partyRelationShipIdCamId = partyRelationShipIdCamId;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	
	
}
