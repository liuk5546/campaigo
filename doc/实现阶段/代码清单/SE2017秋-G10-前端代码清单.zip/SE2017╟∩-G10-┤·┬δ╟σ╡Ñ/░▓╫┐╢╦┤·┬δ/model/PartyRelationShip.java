package com.example.admin.campaigo.model;

public class PartyRelationShip {
	private int partyRelationShipId;
	private int partyRelationShipIdCamId;
	private int role;
	
	public int getPartyRelationShipId() {
		return partyRelationShipId;
	}
	public void setPartyRelationShipId(int partyRelationShipId) {
		this.partyRelationShipId = partyRelationShipId;
	}
	public int getPartyRelationShipIdCamId() {
		return partyRelationShipIdCamId;
	}
	public void setPartyRelationShipIdCamId(int partyRelationShipIdCamId) {
		this.partyRelationShipIdCamId = partyRelationShipIdCamId;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	
	
}
