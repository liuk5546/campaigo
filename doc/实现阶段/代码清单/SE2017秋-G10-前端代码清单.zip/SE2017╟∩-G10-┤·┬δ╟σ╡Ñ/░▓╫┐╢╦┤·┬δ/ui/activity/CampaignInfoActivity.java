package com.example.admin.campaigo.ui.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.example.admin.campaigo.R;
import com.example.admin.campaigo.model.User;
import com.example.admin.campaigo.network.HttpUtil;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Response;

public class CampaignInfoActivity extends AppCompatActivity {
    TextView text_name;
    TextView text_start;
    TextView text_end ;
    TextView text_endead ;
    TextView text_describe ;
    String campaignId;
    String DOMIN="http://115.159.55.118/";
    String url="http://115.159.55.118/campaign/register?id=";
    String hasTokenPartInurl = "http://115.159.55.118/campaign/regStatus?campaiId=";
    String hasToken;
    Button button_TakePart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_campaign_info);
        text_name= (TextView) findViewById(R.id.text_campaignInfo_name);
        text_start = (TextView) findViewById(R.id.text_campaignInfo_start);
        Intent intent = getIntent();
        text_name.setText(intent.getStringExtra("name"));
        text_start.setText(intent.getStringExtra("startTime"));
//        text_endead.setText(intent.getStringExtra("endeadTime"));
        button_TakePart = (Button) findViewById(R.id.button_takePartIn);
        campaignId = String.valueOf(intent.getIntExtra("id",0));
        Log.e("id", campaignId);
        hasTokenPartInurl = hasTokenPartInurl + campaignId + "&userid=" + getId();
        url = url + getId() + "&caid=" + campaignId;
        Log.e("=====》》》", url);
        HttpUtil.sendOkHttpRequest(hasTokenPartInurl, new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("TakePartInError", "Net Error");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                hasToken = response.body().string();
                Log.e("has??", hasToken);
            }
        });

        button_TakePart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getPosition().equals("stu")&&hasToken.equals("false")) {
                    new TakePartTask().execute();
                    HttpUtil.sendOkHttpRequest(hasTokenPartInurl, new okhttp3.Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            Log.e("TakePartInError", "Net Error");
                        }

                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            hasToken = response.body().string();
                            Log.e("has??", hasToken);
                        }
                    });
                    return;
                } else if (getPosition().equals("stu") && hasToken.equals("true")) {
                    Toast.makeText(CampaignInfoActivity.this, "您已经参与过", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(CampaignInfoActivity.this, "您的用户身份不能参加活动", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    class TakePartTask extends AsyncTask<Void, Integer, Boolean> {
        @Override
        protected void onPreExecute() {
            Log.d("TakePartPreExecute", "Success");

        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            Log.d("TakePartPostExecute", "Success");
            Toast.makeText(CampaignInfoActivity.this, "参与成功", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {

        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            HttpUtil.sendOkHttpRequest(url, new okhttp3.Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e("TakePartInError", "Net Error");
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    Log.e("TakePartinresponse", "ok!!!!");
                }
            });
            return null;
        }
    }

    private String UserPreferencetoJson() {
        SharedPreferences pref = getSharedPreferences("user_Info", MODE_PRIVATE);
        String json = pref.getString("User_Json", "");
        return json;
    }
    private String getPosition() {
        String userJson = UserPreferencetoJson();
        User user = JSON.parseObject(userJson, User.class);
        Log.e("position", userJson);
        return user.getPosition();
    }
    private String getId() {
        String userJson = UserPreferencetoJson();
        User user = JSON.parseObject(userJson, User.class);
        Log.e("id", userJson);
        return user.getId();
    }
}
